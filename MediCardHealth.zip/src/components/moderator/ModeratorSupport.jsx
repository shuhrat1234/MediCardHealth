import React from 'react'

function ModeratorSupport() {
  return (
    <div className='min-h-full w-full bg-[#e4f1ff] p-5'>
        <h1 className='text-2xl'>ModeratorSupport</h1>
    </div>
  )
}

export default ModeratorSupport
