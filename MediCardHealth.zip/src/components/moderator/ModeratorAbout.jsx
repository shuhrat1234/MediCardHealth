import React from 'react'

function ModeratorAbout() {
  return (
    <div className='min-h-full w-full bg-[#e4f1ff] p-5'>
        <h1 className='text-2xl'>ModeratorAbout</h1>
    </div>
  )
}

export default ModeratorAbout
