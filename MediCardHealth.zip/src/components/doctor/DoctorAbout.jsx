import React from 'react'

function DoctorAbout() {
  return (
    <div className='min-h-full w-full bg-[#f7f7f7] p-5'>
      <h1 className='text-2xl'>Boshqaruv paneli Doctor Uchun</h1>
    </div>
  )
}

export default DoctorAbout
